import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-devexpressgrid',
  templateUrl: './devexpressgrid.component.html',
  styleUrls: ['./devexpressgrid.component.scss']
})
export class DevexpressgridComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

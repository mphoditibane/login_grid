import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DevexpressgridComponent } from './devexpressgrid.component';

describe('DevexpressgridComponent', () => {
  let component: DevexpressgridComponent;
  let fixture: ComponentFixture<DevexpressgridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DevexpressgridComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DevexpressgridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

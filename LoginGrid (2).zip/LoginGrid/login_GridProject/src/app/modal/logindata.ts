export class LogInData {
    private emailaddress: string;
    private password: string;

    constructor(emailaddress: string, password: string) {
        this.emailaddress = emailaddress;
        this.password = password;
    }

    getEmail(): string {
        return this.emailaddress;
    }

    getPassword(): string {
        return this.password;
    }

}
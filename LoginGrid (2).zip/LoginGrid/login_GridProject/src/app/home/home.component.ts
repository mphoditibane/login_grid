import { Component, OnInit,  Pipe, PipeTransform, enableProdMode } from '@angular/core';

//Grid
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import {
  DxDataGridModule,
  DxBulletModule,
  DxTemplateModule,
} from 'devextreme-angular';

import DataSource from 'devextreme/data/data_source';
import { DataService } from '../service/data.service';
if (!/localhost/.test(document.location.host)) {
  enableProdMode();
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  providers: [DataService]
})
export class HomeComponent implements OnInit {
  hideGridComponent : boolean = true;
  hideDevexpress : boolean = false;
  performanceData: any[] =
  [{
    "ticker": "IVV",
    "asset class code": "EQ",
    "asset class Name": "Equity",
    "name": "iShares Core S&P 500 ETF",
    "returns 1Y": 1.74,
    "returns 2Y": 1.2,
    "returns 3Y": 2.2,
    "returns 4Y": -0.2
  }, {
    "ticker": "EFA",
    "asset class code": "EQ",
    "asset class Name": "Equity",
    "name": "iShares MSCI EAFE ETF",
    "returns 1Y": 1.74,
    "returns 2Y": 1.2,
    "returns 3Y": 2.2,
    "returns 4Y": -0.2
  }, {
    "ticker": "AGG",
    "asset class code": "FI",
    "asset class Name": "Fixed Income",
    "name": "iShares Core U.S. Aggregate Bond ETF",
    "returns 1Y": 1.24,
    "returns 2Y": 2.2,
    "returns 3Y": 2.9,
    "returns 4Y": -0.4
  }, {
    "ticker": "IWF",
    "asset class code": "EQ",
    "asset class Name": "Equity",
    "name": "iShares Russell 1000 Growth ETF",
    "returns 1Y": 3.14,
    "returns 2Y": 3.1,
    "returns 3Y": 4.2,
    "returns 4Y": -0.4
  }];
  dataSource : any;
  myresult: any;
  collapsed = false;

  contentReady = (e: { component: { expandRow: (arg0: string[]) => void; }; }) => {
    if (!this.collapsed) {
      this.collapsed = true;
      e.component.expandRow(['EnviroCare']);
    }
  };

  customizeTooltip = (pointsInfo: { originalValue: string; }) => ({ text: `${parseInt(pointsInfo.originalValue)}%` });
 
  constructor(private dataservice : DataService) { 
    //this.dataSource = dataservice.getDataSource();
  }

  ngOnInit(): void {
    this.dataservice.getDataSource()
    .subscribe((result: any) => {

      this.myresult = result.PersonalInfolistModel;
      console.log(this.myresult)
      this.dataSource = this.myresult;
    });
  }

  onGrid(){
    this.hideDevexpress = true;
    this.hideGridComponent = false;
  }
  onGridDevexpress(){
    this.hideDevexpress = false;
    this.hideGridComponent = true;
  }
}

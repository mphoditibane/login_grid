import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { LogInData } from '../modal/logindata';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  
  private readonly mockedUser = new LogInData('mph@gmail.com', 'test123')
  isAuthenticated = false;
  constructor(private router : Router) { }

  authenticate(logInData: LogInData): boolean{
    if(this.checkCredentials(logInData)){
      this.isAuthenticated = true;
      this.router.navigate(['home']);
      return true;
    }
    this.isAuthenticated = false;
    return false;

  }

  private checkCredentials(logInData: LogInData): boolean {
    return this.checkEmail(logInData.getEmail()) && this.checkPassword(logInData.getPassword());
  }

  private checkEmail(emailaddress: string): boolean {
    return emailaddress === this.mockedUser.getEmail();
  }

  private checkPassword(password: string): boolean {
    return password === this.mockedUser.getPassword();
  }

  logout() {
    this.isAuthenticated = false;
    this.router.navigate(['']);
  }
}

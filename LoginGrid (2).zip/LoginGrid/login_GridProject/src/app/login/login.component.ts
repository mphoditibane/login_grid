import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LogInData } from '../modal/logindata';
import { AuthenticationService } from '../service/authentication.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  isFormInValid = false;
  areCredentialsInvalid = false;
  constructor( private authenticationService: AuthenticationService) { }

  ngOnInit(): void {
  }


  onSubmit(LogInForm : NgForm) {
    if(!LogInForm.valid) {
      this.isFormInValid = true;
      this.areCredentialsInvalid = false;
      return;
    }
    this.checkCredentials(LogInForm);
    
  }

  private checkCredentials(LogInForm: NgForm){
    const logInData = new LogInData(LogInForm.value.emailaddress, LogInForm.value.password);
    if(!this.authenticationService.authenticate(logInData)) {
      this.isFormInValid = false;
      this.areCredentialsInvalid = true;
    }
  }
}
